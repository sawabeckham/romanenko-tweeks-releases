#!/bin/zsh
# Собирает macOS-приложение из сайта и обновляет уже созданные.
#
#   ./make-webapp.sh "Название" https://site.com [-i иконка.png] [-o папка] [--no-restore] [--open]
#   ./make-webapp.sh --update "/Applications/RomanenkoApp/Сайт.app" [...]   пересобрать на текущей версии оболочки
#   ./make-webapp.sh --update-all [папка]          обновить все устаревшие (по умолчанию /Applications/RomanenkoApp)
#   ./make-webapp.sh --list [папка]                             показать созданные приложения и их версии
#
# При обновлении сохраняются название, адрес, иконка, настройки и входы на сайты (bundle id не меняется).

set -euo pipefail

HERE="${0:A:h}"
APPS_DIR="/Applications/RomanenkoApp"   # все программы Романенко — в одной папке
VERSION="$(<"$HERE/VERSION")"
PB=/usr/libexec/PlistBuddy

usage() {
  cat <<EOF
WebApp Maker $VERSION
Использование: $0 "Название" URL [опции]
  -i, --icon FILE     своя иконка (png/jpg/icns/svg); иначе берётся с сайта
  -o, --out DIR       куда положить .app (по умолчанию /Applications/RomanenkoApp)
      --no-restore    не восстанавливать вкладки при следующем запуске
      --open          запустить приложение после сборки
       $0 --update ПРИЛОЖЕНИЕ.app [...]
       $0 --update-all [ПАПКА]
       $0 --list [ПАПКА]
EOF
  exit 1
}

# WA_BIN_DIR — готовые бинарники (так скрипт вызывает «WebApp Maker.app»)
prepare_binaries() {
  if [[ -n "${WA_BIN_DIR:-}" ]]; then
    BUILD="$WA_BIN_DIR"
    return
  fi
  BUILD="$HERE/.build"
  mkdir -p "$BUILD"
  # Компилируем оболочку и генератор иконок (только если исходники поменялись)
  compile() {   # compile ИМЯ ФАЙЛЫ...
    local bin="$BUILD/$1" f stale=false
    shift
    [[ -x "$bin" && ! "$HERE/VERSION" -nt "$bin" ]] || stale=true
    for f in "$@"; do [[ "$f" -nt "$bin" ]] && stale=true; done
    if $stale; then
      echo "• Компилирую ${bin:t}…"
      # Только Apple Silicon (Intel не поддерживаем), macOS 13+
      swiftc -O -swift-version 5 -target arm64-apple-macos13.0 "$@" -o "$bin"
    fi
  }
  compile WebAppShell "$HERE"/Sources/Shell/*.swift "$HERE"/Sources/Shared/*.swift
  compile IconMaker "$HERE/Sources/IconMaker.swift"
}

# Копия Romanenko Tweeks (в них WebApp Maker — вкладка «Веб-приложения») внутри каждого приложения: перенесённое на
# другой Mac, оно предложит их установить. Берём те Твики, которые нас вызвали
# (WA_BIN_DIR = «…/Romanenko Tweeks.app/Contents/Resources/bin»), иначе установленные в /Applications/RomanenkoApp.
# Архивом, а не .app — иначе macOS видела бы вторые Твики.
prepare_maker_zip() {
  local maker="${WA_MAKER_APP:-}"
  [[ -z "$maker" && -n "${WA_BIN_DIR:-}" ]] && maker="${WA_BIN_DIR:h:h:h}"
  [[ -z "$maker" ]] && maker="$APPS_DIR/Romanenko Tweeks.app"
  MAKER_ZIP=""
  if [[ "$maker" == *.app && -f "$maker/Contents/Info.plist" ]]; then
    MAKER_ZIP_DIR="$(mktemp -d)"
    MAKER_ZIP="$MAKER_ZIP_DIR/Romanenko Tweeks.zip"
    ditto -c -k --keepParent "$maker" "$MAKER_ZIP"
  else
    echo "  Romanenko Tweeks не найдены — приложение будет без встроенного конструктора"
  fi
}
trap '[[ -n "${MAKER_ZIP_DIR:-}" ]] && rm -rf "$MAKER_ZIP_DIR"; true' EXIT

plist_get() { $PB -c "Print :$2" "$1/Contents/Info.plist" 2>/dev/null || true; }
is_webapp() { [[ -n "$(plist_get "$1" WAHomeURL)" ]]; }
app_version() { local v="$(plist_get "$1" WAShellVersion)"; echo "${v:-0}"; }
is_outdated() {
  local v="$(app_version "$1")"
  [[ "$v" != "$VERSION" && "$(printf '%s\n' "$v" "$VERSION" | sort -V | head -1)" == "$v" ]]
}
xml_escape() { sed -e 's/&/\&amp;/g' -e 's/</\&lt;/g' -e 's/>/\&gt;/g' <<< "$1"; }

# build_app ИМЯ URL ПАПКА ИКОНКА(.icns|картинка|"") RESTORE BUNDLE_ID
build_app() {
  local name="$1" url="$2" out="$3" icon="$4" restore="$5" bundle_id="$6"
  local final="$out/$name.app" tmp app
  # Перезаписываем только приложения, сделанные этим же скриптом
  if [[ -e "$final" ]] && ! is_webapp "$final"; then
    echo "Уже есть $final, и это не веб-приложение отсюда — не трогаю."; return 1
  fi

  # Собираем и подписываем во временной папке: в папках, которые синхронизирует iCloud
  # (например, «Документы»), codesign не может подписать бандл
  tmp="$(mktemp -d)"
  app="$tmp/$name.app"
  echo "• Собираю $final (версия $VERSION)"
  mkdir -p "$app/Contents/MacOS" "$app/Contents/Resources"
  cp "$BUILD/WebAppShell" "$app/Contents/MacOS/$name"
  [[ -n "${MAKER_ZIP:-}" ]] && cp "$MAKER_ZIP" "$app/Contents/Resources/Romanenko Tweeks.zip"

  if [[ "$icon" == *.icns ]]; then
    cp "$icon" "$app/Contents/Resources/AppIcon.icns"
  else
    echo "• Иконка"
    "$BUILD/IconMaker" "$url" "$tmp/AppIcon.iconset" "$name" "$icon"
    iconutil -c icns "$tmp/AppIcon.iconset" -o "$app/Contents/Resources/AppIcon.icns"
  fi

  cat > "$app/Contents/Info.plist" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleName</key><string>$(xml_escape "$name")</string>
  <key>CFBundleDisplayName</key><string>$(xml_escape "$name")</string>
  <key>CFBundleExecutable</key><string>$(xml_escape "$name")</string>
  <key>CFBundleIdentifier</key><string>$bundle_id</string>
  <key>CFBundleIconFile</key><string>AppIcon</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>CFBundleShortVersionString</key><string>$VERSION</string>
  <key>CFBundleVersion</key><string>$VERSION</string>
  <key>CFBundleDevelopmentRegion</key><string>ru</string>
  <key>LSMinimumSystemVersion</key><string>13.0</string>
  <key>LSArchitecturePriority</key><array><string>arm64</string></array>
  <key>NSHighResolutionCapable</key><true/>
  <key>NSSupportsAutomaticTermination</key><false/>
  <key>NSCameraUsageDescription</key><string>Сайт запрашивает доступ к камере.</string>
  <key>NSMicrophoneUsageDescription</key><string>Сайт запрашивает доступ к микрофону.</string>
  <key>NSLocationUsageDescription</key><string>Сайт запрашивает геопозицию.</string>
  <key>WAHomeURL</key><string>$(xml_escape "$url")</string>
  <key>WARestoreTabs</key><$restore/>
  <key>WAShellVersion</key><string>$VERSION</string>
</dict>
</plist>
EOF

  xattr -cr "$app"   # служебные атрибуты файлов мешают подписи
  codesign --force --sign - "$app" >/dev/null 2>&1 || { echo "Не удалось подписать $final"; rm -rf "$tmp"; return 1; }

  mkdir -p "$out"
  rm -rf "$final"
  ditto "$app" "$final"
  rm -rf "$tmp"
  touch "$final"   # чтобы Finder/Dock подхватили новую иконку
  echo "✓ Готово: $final"
  BUILT_APP="$final"
}

update_app() {
  local app="${1%/}"
  is_webapp "$app" || { echo "✗ $app — не веб-приложение отсюда, пропускаю"; return 1; }
  local name url restore bundle_id old tmp
  name="$(plist_get "$app" CFBundleName)"
  url="$(plist_get "$app" WAHomeURL)"
  restore="$(plist_get "$app" WARestoreTabs)"; [[ "$restore" == false ]] || restore=true
  bundle_id="$(plist_get "$app" CFBundleIdentifier)"
  old="$(app_version "$app")"
  # Открытое приложение не подменяем: WebApp Maker спросит «Закрыть и перезапустить?» и обновит сам
  if pgrep -f "$app/Contents/MacOS/" >/dev/null; then
    echo "• «$name» сейчас открыто — пропускаю. Обновите его в WebApp Maker: он предложит закрыть и перезапустить"
    return 1
  fi
  tmp="$(mktemp -d)"
  cp "$app/Contents/Resources/AppIcon.icns" "$tmp/AppIcon.icns"
  echo "• Обновляю «$name»: $old → $VERSION"
  build_app "$name" "$url" "${app:h}" "$tmp/AppIcon.icns" "$restore" "$bundle_id"
  rm -rf "$tmp"
  return 0
}

list_apps() {
  local dir="${1:-$APPS_DIR}" app found=false
  for app in "$dir"/*.app(N); do
    is_webapp "$app" || continue
    found=true
    local mark="актуально"
    is_outdated "$app" && mark="можно обновить до $VERSION"
    printf '%s\t%s\t%s\n' "${app:t:r}" "$(app_version "$app")" "$mark"
  done
  $found || echo "В $dir нет веб-приложений"
}

# MARK: - Разбор аргументов

case "${1:-}" in
  --list)
    list_apps "${2:-}"; exit 0 ;;
  --update)
    shift; (( $# )) || usage
    prepare_binaries
    prepare_maker_zip
    for app in "$@"; do update_app "$app" || true; done
    exit 0 ;;
  --update-all)
    dir="${2:-$APPS_DIR}"
    prepare_binaries
    prepare_maker_zip
    count=0
    for app in "$dir"/*.app(N); do
      is_webapp "$app" && is_outdated "$app" || continue
      update_app "$app" && count=$((count + 1))
    done
    echo "Обновлено приложений: $count"
    exit 0 ;;
  --version)
    echo "$VERSION"; exit 0 ;;
esac

NAME="" URL="" ICON="" OUT="$APPS_DIR" RESTORE=true OPEN=false
while (( $# )); do
  case "$1" in
    -i|--icon) ICON="$2"; shift 2 ;;
    -o|--out) OUT="$2"; shift 2 ;;
    --no-restore) RESTORE=false; shift ;;
    --open) OPEN=true; shift ;;
    -h|--help) usage ;;
    -*) echo "Неизвестная опция: $1"; usage ;;
    *) if [[ -z "$NAME" ]]; then NAME="$1"; elif [[ -z "$URL" ]]; then URL="$1"; else usage; fi; shift ;;
  esac
done
[[ -n "$NAME" && -n "$URL" ]] || usage
[[ "$URL" == *://* ]] || URL="https://$URL"
[[ -z "$ICON" || -f "$ICON" ]] || { echo "Нет файла иконки: $ICON"; exit 1; }

prepare_binaries
prepare_maker_zip

# Пересоздание поверх существующего приложения сохраняет его bundle id, а с ним и входы на сайты
EXISTING="$OUT/$NAME.app"
if [[ -e "$EXISTING" ]] && is_webapp "$EXISTING"; then
  BUNDLE_ID="$(plist_get "$EXISTING" CFBundleIdentifier)"
else
  HOST="$(echo "$URL" | sed -E 's#^[a-zA-Z]+://([^/:]+).*#\1#')"
  SLUG="$(echo "$NAME" | iconv -f utf-8 -t ascii//TRANSLIT 2>/dev/null | tr -cd '[:alnum:]' | tr '[:upper:]' '[:lower:]' || true)"
  [[ -n "$SLUG" ]] || SLUG="$(echo "$HOST" | tr -cd '[:alnum:]' | tr '[:upper:]' '[:lower:]')"
  BUNDLE_ID="local.webapp.$SLUG"
fi

build_app "$NAME" "$URL" "$OUT" "$ICON" "$RESTORE" "$BUNDLE_ID"
$OPEN && open "$BUILT_APP"
exit 0
